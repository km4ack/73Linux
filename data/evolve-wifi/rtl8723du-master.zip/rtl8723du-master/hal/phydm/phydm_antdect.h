/* SPDX-License-Identifier: GPL-2.0 */
/* Copyright(c) 2007 - 2017 Realtek Corporation */

#ifndef	__PHYDMANTDECT_H__
#define    __PHYDMANTDECT_H__

#define ANTDECT_VERSION	"2.1"	/*2015.07.29 by YuChen*/

void
odm_sw_ant_detect_init(
	void		*p_dm_void
);


#endif
