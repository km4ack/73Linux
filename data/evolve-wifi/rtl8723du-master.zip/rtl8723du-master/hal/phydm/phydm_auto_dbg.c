// SPDX-License-Identifier: GPL-2.0
/* Copyright(c) 2007 - 2017 Realtek Corporation */

/* ************************************************************
 * include files
 * ************************************************************ */

#include "mp_precomp.h"
#include "phydm_precomp.h"

void
phydm_auto_dbg_engine(
	void			*p_dm_void
)
{
}

void
phydm_auto_dbg_engine_init(
	void		*p_dm_void
)
{
}
